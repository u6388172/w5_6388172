import 'package:flutter/material.dart';

void main() => runApp(MyApp());


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Service',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}


class HomePage extends StatelessWidget {
   int _selectedIndex = 0;

  void _onTabTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  @override
 Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/images/4.png'), 
              fit: BoxFit.cover,
            ),
          ),
        ),
      ),
  body: GridView.count(
  crossAxisCount: 2,
  mainAxisSpacing: 16.0,
  crossAxisSpacing: 16.0,
  padding: EdgeInsets.all(16.0),
  children: [
    SizedBox(
      width: 100.0,
      height: 100.0,
      child: _buildButtonWithIconAndNavigate(
        context,
        Icons.cases_rounded,
        'Product',
        () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ProductScreen()),
          );
        },
      ),
    ),
    SizedBox(
      width: 100.0,
      height: 100.0,
      child: _buildButtonWithIconAndNavigate(
        context,
        Icons.room_service_outlined,
        'Service',
        () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ServicePage()),
          );
        },
      ),
    ),
    SizedBox(
      width: 100.0,
      height: 100.0,
      child: _buildButtonWithIconAndNavigate(
        context,
        Icons.phone,
        'Contact us',
        () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => Contactus()),
          );
        },
      ),
    ),
    SizedBox(
      width: 100.0,
      height: 100.0,
      child: _buildButtonWithIconAndNavigate(
        context,
        Icons.people,
        'About us',
        () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => Aboutus()),
          );
        },
      ),
    ),
  ],
),
              bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color.fromARGB(255, 67, 81, 87),
        unselectedItemColor: Colors.black,
        selectedItemColor: Colors.black,
        items: [
          BottomNavigationBarItem(
    icon: Icon(Icons.home),
    label: 'Home',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.shop),
    label: 'Shop',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.code),
    label: 'QRscan',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.person),
    label: 'Profile',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.settings),
    label: 'Settings',
  ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onTabTapped,
        ),
    );
  }

  Widget _buildButtonWithIconAndNavigate(BuildContext context, IconData icon, String label, VoidCallback onPressed) {
    return InkWell(
      onTap: onPressed,
        child:Container(
          width: 40,
          height: 40,
          color: Colors.blue,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 36.0,
          ),
          SizedBox(height: 8.0),
          Text(
            label,
            style: TextStyle(fontSize: 14.0),
          ),
        ],
      ),
      ),
      
    );
  }
}

void setState(Null Function() param0) {
}

class ProductScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Product Screen'),
      ),
      body: Center(
        child: Text('Product Screen'),
      ),
    );
  }
}
class Contactus extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Contactus Screen'),
      ),
      body: Center(
        child: Text('Contactus Screen'),
      ),
    );
  }
}

class Aboutus extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Aboutus Screen'),
      ),
      body: Center(
        child: Text('Aboutus Screen'),
      ),
    );
  }
}



class ServicePage extends StatefulWidget {
 @override
  _ServiceState createState() => _ServiceState();
}
class _ServiceState extends State<ServicePage> {
  int _selectedIndex = 0;
  void _onTabTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Service'),
      ),
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 12.0),
            TextFormField(
              decoration: InputDecoration(
                labelText: 'When my product can be delivered?',
                border: OutlineInputBorder(),
              ),
            ),
             SizedBox(height: 12.0),
            TextFormField(
              decoration: InputDecoration(
                labelText: 'I have missing or not recieve my product',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 12.0),
            TextFormField(
              decoration: InputDecoration(
                labelText: 'How can I do for refunding if  has any probems?',
                border: OutlineInputBorder(),
              ),
              obscureText: true,
            ),
             SizedBox(height: 25.0),
            TextFormField(
              decoration: InputDecoration(
                labelText: 'Why the deliver didn’t on time?',
                border: OutlineInputBorder(),
              ),
            ),
           ElevatedButton(
            child : const Text ( '>') ,
              onPressed: () {
                Navigator . push (
context ,
MaterialPageRoute ( builder :
( context ) => const SecondRoute ()) ,
);
              }, 
            ),
           ],
      ),
        ),
         bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color.fromARGB(255, 67, 81, 87),
        unselectedItemColor: Colors.black,
        selectedItemColor: Colors.black,
        items: [
          BottomNavigationBarItem(
    icon: Icon(Icons.home),
    label: 'Home',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.shop),
    label: 'Shop',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.code),
    label: 'QRscan',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.person),
    label: 'Profile',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.settings),
    label: 'Settings',
  ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onTabTapped,
        ),
    );
  }
}
class SecondRoute extends StatefulWidget {
  const SecondRoute({Key? key}) : super(key: key);

  @override
  _SecondRouteState createState() => _SecondRouteState();
}

class _SecondRouteState extends State<SecondRoute> {
  int _currentIndex = 0;

  void _onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Service'),
      ),
      body: Stack(
        children: [
          Positioned(
            top: 10.0,
            left: 10.0,
            child: ElevatedButton(
              onPressed: () {
                 Navigator . push (context ,
MaterialPageRoute ( builder :( context ) => HomePage (),
) ,
);
              },
              child: const Text('< Back to Homepage'),
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(height: 10),
                Text(
                  'service done',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: _onTabTapped,
        backgroundColor: const Color.fromARGB(255, 67, 81, 87),
        unselectedItemColor: Colors.black,
        selectedItemColor: Colors.black,
        items: [
          BottomNavigationBarItem(
    icon: Icon(Icons.home),
    label: 'Home',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.shop),
    label: 'Shop',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.code),
    label: 'QRscan',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.person),
    label: 'Profile',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.settings),
    label: 'Settings',
  ),
        ],
      ),
    );
  }
}
